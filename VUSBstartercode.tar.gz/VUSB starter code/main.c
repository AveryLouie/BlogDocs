#define F_CPU  12800000
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>
#include <avr/wdt.h>
#include "usbdrv.h"
#include "oddebug.h"
#include <util/delay.h>
#include "usbconfig.h"
int xval;
int yval;
int on;
int ret=42;
//for setting up internal RC oscillator.  include these next two functions only if you are not using a crystal
static void calibrateOscillator(void)
{
uchar       step = 128;
uchar       trialValue = 0, optimumValue;
int         x, optimumDev, targetValue = (unsigned)(1499 * (double)F_CPU / 10.5e6 + 0.5);
 
    /* do a binary search: */
    do{
        OSCCAL = trialValue + step;
        x = usbMeasureFrameLength();    // proportional to current real frequency
        if(x < targetValue)             // frequency still too low
            trialValue += step;
        step >>= 1;
    }while(step > 0);
    /* We have a precision of +/- 1 for optimum OSCCAL here */
    /* now do a neighborhood search for optimum value */
    optimumValue = trialValue;
    optimumDev = x; // this is certainly far away from optimum
    for(OSCCAL = trialValue - 1; OSCCAL <= trialValue + 1; OSCCAL++){
        x = usbMeasureFrameLength() - targetValue;
        if(x < 0)
            x = -x;
        if(x < optimumDev){
            optimumDev = x;
            optimumValue = OSCCAL;
        }
    }
    OSCCAL = optimumValue;
}
 
void    usbEventResetReady(void)
{
    cli();  // usbMeasureFrameLength() counts CPU cycles, so disable interrupts.
    calibrateOscillator();
    sei();
    eeprom_write_byte(0, OSCCAL);   // store the calibrated value in EEPROM
}


//Critical stuff

usbMsgLen_t usbFunctionSetup(uchar setupData[8])
{
    usbRequest_t *rq = (void *)setupData;   // cast to structured data for parsing
    	if(rq->bRequest==0b10000000){
    		on=rq->bRequest;
    		xval=rq->wValue.word;
    		yval=rq->wIndex.word;
    		return 0;//#bytes return to comp from usbdata look at powerswitch
    	}
    	else{
    		*usbMsgPtr=ret;
    		return 2;
    		}
}

int main(){
	// Disable clock divider
	CLKPR=0x80;
	CLKPR=0;
	sei();
	wdt_disable();
	usbInit();	
	while (1){
		usbPoll();
		}
	
	}
	