from Tkinter import *
import usb.core, usb.util
import time, struct


class lazy:
	#init is called every time we create an instance of class gui, so I am using it to create and pack all the tk objects
	def __init__(self, master):
		self.lower=Frame(master)		
		self.upper=Frame(master)
		self.bmRequestType=Entry(self.lower)
		self.bmRequest=Entry(self.lower)
		self.wValue=Entry(self.lower)
		self.wIndex=Entry(self.lower)
		self.wLength=Entry(self.lower)
		self.VID=Entry(self.upper)
		self.PID=Entry(self.upper)		
		
			#pack all the things!
		
		self.upper.pack(side=TOP)
		self.lower.pack(side=BOTTOM)
		
		#variables for text fields
		self.deviceinfo = StringVar()
		self.deviceinfo.set("Search for device")		
		
		self.dev=Entry(self.upper,textvariable=self.deviceinfo)
		
		self.go = Button(self.lower, text="Send", command=lambda: self.sendfun(self.bmRequestType.get(), self.bmRequest.get(), self.wValue.get() , self.wIndex.get(), self.getwLength()))
		self.search=Button(self.upper, text="Search",command=lambda: self.searchfun(self.VID.get(),self.PID.get()))
		
		#some labels, ew
		self.VIDlabel = Label(self.upper)
		self.VIDlabel["text"] = "Vendor IDAX(0xXXXX):"
		
		self.PIDlabel = Label(self.upper)
		self.PIDlabel["text"] = "Product ID(0xXXXX):"		
		
		self.devlabel = Label(self.upper)
		self.devlabel["text"] = "Device info:"		
		
		self.bmRequestTypelabel = Label(self.lower)
		self.bmRequestTypelabel["text"] = "bmRequestType (0xXXXX):"
		
		self.bmRequestlabel = Label(self.lower)
		self.bmRequestlabel["text"] = "bmRequest (0xXXXX):"
		
		self.wValuelabel = Label(self.lower)
		self.wValuelabel["text"] = "wValue (0xXXXX):"
		
		self.wIndexlabel = Label(self.lower)
		self.wIndexlabel["text"] = "wIndex (0xXXXX):"
		
		self.wLengthlabel = Label(self.lower)
		self.wLengthlabel["text"] = "wLength (0xXXXX):"
		
		
		#pack the bottom and the labels
		self.bmRequestTypelabel.pack(side=LEFT)
		self.bmRequestType.pack(side=LEFT)
		
		self.bmRequestlabel.pack(side=LEFT)
		self.bmRequest.pack(side=LEFT)
		
		self.wValuelabel.pack(side=LEFT)
		self.wValue.pack(side=LEFT)
		
		self.wIndexlabel.pack(side=LEFT)
		self.wIndex.pack(side=LEFT)
		
		self.wLengthlabel.pack(side=LEFT)
		self.wLength.pack(side=LEFT)
		
		self.go.pack(side=RIGHT)
		
		#upper things
		self.VIDlabel.pack(side=LEFT)
		self.VID.pack(side=LEFT)
		
		self.PIDlabel.pack(side=LEFT)
		self.PID.pack(side=LEFT)
		
		self.search.pack(side=LEFT)		
		
		self.devlabel.pack(side=LEFT)
		self.dev.pack(side=LEFT)
		
	def searchfun(self,VID,PID):
		self.device=usb.core.find(idVendor=int(VID,16), idProduct=int(PID,16))
		print(VID,PID)
		print(self.device)
		if self.device is None:
			self.deviceinfo.set("Device not found!")
		else:
			self.deviceinfo.set("Device found!")
	
	def sendfun(self, bmRequestType, bmRequest, wValue, wIndex, wLength):
		if self.device is not None:
			try:
				print("sending")
				self.device.ctrl_transfer(int(bmRequestType,16),int(bmRequest,16),int(wValue,16),int(wIndex,16),wLength)
			except usb.core.USBError, e:
				print('exception')
				
	def getwLength(self):
		if self.wLength.get() == '0' or '0x00' or 'None' or '':
			return None
		else:
			return int(self.wLength.get(),16)
				
		
root=Tk()
root.title("USBInter")
GUI=lazy(root)
root.mainloop()